# Schema-matcher API

## Endpoints of the API:
- **/schema**
- **/data**
### Pattern for input data of /schema:
```perl
{
    "title": $table_name,
    "type": "array",
    "items": {
        "type": "object",
        "properties": {
            $column_name: {
                "type": $column_type,
                "enum": [
                            $type_name,
                            $type_name
                ],
                (optional)"minLength": $string_minimum_length,
                (optional)"maxLength": $string_maximum_length,
                (optional)"minimum": $number_minimum_value,
                (optional)"maximum": $number_maximum_value,
                (optional)"default": $default_value,
                (optional)"unique": true,
                (optional)"pattern": $string_pattern_regex
                (optional)"format": $string_format
            },
            ...
        },
         "required": [
             $column_name,
             $column_name,
             ...
         ],
         "primaryKeys": [
             $column_name,
             $column_name,
             ...
         ],
         (optional)"foreignKeys": {
            $column_name: {
                "table": $referenced_table_name,
                "column": $referenced_column_name
            },
            ...
         }
    }
}
```
Additional information:
- A field can either have an "enum" or a "type" parameter, can't be both!
- "type" can be an array if null has to be set as an acceptable input, eg.:
```perl
"fields": {
        "email": {
            "type": [ "string", "null" ],
            "unique": true
        }
}
```

### Pattern for input data of /data:
```perl
{
	$column_name: $value,
	$column_name: $value,
	...
}
```

## Some additional information:
Schemas table has to contain 3 fields:
- id (serial)
- schema (varchar)
- table_name (varchar)

Supported data types: integer(int), string(varchar), boolean(bool), number(float8)<br/>
Altering columns is not supported yet. (Change type, change default value, change unique constraint etc.)
