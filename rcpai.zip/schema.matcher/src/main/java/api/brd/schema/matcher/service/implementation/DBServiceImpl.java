package api.brd.schema.matcher.service.implementation;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import api.brd.schema.matcher.entity.Schema;
import api.brd.schema.matcher.repository.SchemaRepository;
import api.brd.schema.matcher.service.DBService;

@Service
public class DBServiceImpl implements DBService {

    @Autowired
    private EntityManagerFactory entityManagerFactory;

    @Autowired
    private SchemaRepository schemaRepository;

    @Override
    public void executeSQLs(List<String> sqls) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        try {
            EntityTransaction transaction = entityManager.getTransaction();
            transaction.begin();
            for (String sql : sqls) {
                entityManager.createNativeQuery(sql).executeUpdate();
            }
            transaction.commit();
        }
        finally {
            entityManager.close();
        }
    }

    @Override
    public void saveSchema(String tableName, String input) {
        Schema schema = new Schema();
        schema.setTableName(tableName);
        schema.setSchema_col(input);
        schemaRepository.save(schema);
    }

    @Override
    public void deleteSchema(String tableName) {
        schemaRepository.delete(schemaRepository.findByTableName(tableName));
    }

}
