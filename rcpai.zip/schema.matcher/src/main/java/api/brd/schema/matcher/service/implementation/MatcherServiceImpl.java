package api.brd.schema.matcher.service.implementation;

import api.brd.schema.matcher.entity.Schema;
import api.brd.schema.matcher.exception.InvalidFileFormatException;
import api.brd.schema.matcher.exception.NoMatchingSchemaException;
import api.brd.schema.matcher.helper.Helper;
import api.brd.schema.matcher.repository.SchemaRepository;
import api.brd.schema.matcher.service.DBService;
import api.brd.schema.matcher.service.MatcherService;
import com.fasterxml.jackson.databind.JsonNode;
import com.github.fge.jackson.JsonLoader;
import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonSchema;
import com.github.fge.jsonschema.main.JsonSchemaFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Service
public class MatcherServiceImpl implements MatcherService {

    @Autowired
    private SchemaRepository schemaRepository;

    @Autowired
    private DBService dbService;

    @Autowired
    private Helper helper;

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Override
    public JsonNode findMatchingSchema(String inputData) {
        JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
        try {
            JsonNode data = JsonLoader.fromString(inputData);
            List<Schema> schemas = schemaRepository.findAll();
            for (Schema element : schemas) {
                JsonNode schema = JsonLoader.fromString(element.getSchema_col());
                JsonSchema jsonSchema = factory.getJsonSchema(schema);
                ProcessingReport report = jsonSchema.validate(data);
                if (report.isSuccess()) {
                    return schema;
                }
            }
        } catch (IOException exception) {
            throw new InvalidFileFormatException("Couldn't parse input data to JSON!");
        } catch (ProcessingException exception) {
            throw new InvalidFileFormatException("JSON is not a valid schema!");
        }
        throw new NoMatchingSchemaException();
    }

    @Override
    public String handleInsertion(String inputData, JsonNode schema) {
        try {
            JsonNode data = JsonLoader.fromString(inputData);
            String tableName = schema.get("title").textValue();
            StringBuilder sql = new StringBuilder();
            createInsertStatement(data, tableName, sql);
            JsonNode primaryKeys = schema.get("items").get("primaryKeys");
            if (primaryKeys != null) {
                createOnConflictStatement(primaryKeys, tableName, sql);
                createUpdateStatement(data, schema, sql);
            }
            LOGGER.info(sql.toString());
            dbService.executeSQLs(Collections.singletonList(sql.toString()));
            return "Data successfully inserted into table '" + tableName + "'!";
        } catch (IOException e) {
            throw new InvalidFileFormatException("Couldn't parse input data to JSON!");
        }
    }

    private void createUpdateStatement(JsonNode data, JsonNode schema, StringBuilder sql) {
        Iterator<Map.Entry<String, JsonNode>> fields;
        fields = data.elements().next().fields();
        while (fields.hasNext()) {
            Map.Entry<String, JsonNode> field = fields.next();
            if (!helper.columnIsPrimaryKey(field.getKey(), schema)) {
                sql.append(field.getKey())
                        .append(" = Excluded.")
                        .append(field.getKey())
                        .append(", ");
            }
        }
        sql.delete(sql.length() - 2, sql.length());
    }

    private void createOnConflictStatement(JsonNode primaryKeys, String tableName, StringBuilder sql) {
        sql.append(" ON CONFLICT ON CONSTRAINT ").append(tableName);
        Iterator<JsonNode> primaryKeyElements = primaryKeys.elements();
        while (primaryKeyElements.hasNext()) {
            sql.append("_").append(primaryKeyElements.next().textValue());
        }
        sql.append("_key DO UPDATE SET ");
    }

    private void createInsertStatement(JsonNode data, String tableName, StringBuilder sql) {
        sql.append("INSERT INTO ").append(tableName).append(" (");
        Iterator<Map.Entry<String, JsonNode>> fields = data.elements().next().fields();
        while (fields.hasNext()) {
            sql.append(fields.next().getKey()).append(", ");
        }
        sql.delete(sql.length() - 2, sql.length());
        sql.append(") VALUES (");
        Iterator<JsonNode> elements = data.elements();
        while (elements.hasNext()) {
            fields = elements.next().fields();
            while (fields.hasNext()) {
                sql.append(fields.next().getValue().toString().replace('\"', '\'')).append(", ");
            }
            sql.delete(sql.length() - 2, sql.length());
            sql.append("), (");
        }
        sql.delete(sql.length() - 3, sql.length());
    }

}
