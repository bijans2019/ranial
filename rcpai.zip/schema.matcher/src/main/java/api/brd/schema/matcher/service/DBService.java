package api.brd.schema.matcher.service;

import java.util.List;

public interface DBService {

    void executeSQLs(List<String> sqls);

    void saveSchema(String tableName, String input);

    void deleteSchema(String tableName);

}
