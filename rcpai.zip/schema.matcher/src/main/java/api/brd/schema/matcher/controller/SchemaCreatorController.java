package api.brd.schema.matcher.controller;

import api.brd.schema.matcher.service.SchemaCreatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SchemaCreatorController {

    @Autowired
    private SchemaCreatorService schemaCreatorService;

    @RequestMapping(value = "/schema", method = RequestMethod.POST)
    public String createSchema(@RequestBody String inputData) {
        return schemaCreatorService.handleSchemaCreation(inputData);
    }

}
