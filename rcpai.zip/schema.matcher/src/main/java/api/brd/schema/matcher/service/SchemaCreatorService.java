package api.brd.schema.matcher.service;

import api.brd.schema.matcher.exception.InvalidOperationException;

public interface SchemaCreatorService {

    String handleSchemaCreation(String input) throws InvalidOperationException;

}
