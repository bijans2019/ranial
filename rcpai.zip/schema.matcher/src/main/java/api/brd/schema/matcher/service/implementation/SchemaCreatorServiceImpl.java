package api.brd.schema.matcher.service.implementation;

import api.brd.schema.matcher.exception.InvalidFileFormatException;
import api.brd.schema.matcher.exception.InvalidOperationException;
import api.brd.schema.matcher.exception.SchemaAlreadyExistsException;
import api.brd.schema.matcher.helper.Helper;
import api.brd.schema.matcher.repository.SchemaRepository;
import api.brd.schema.matcher.service.DBService;
import api.brd.schema.matcher.service.SchemaCreatorService;
import com.fasterxml.jackson.databind.JsonNode;
import com.flipkart.zjsonpatch.JsonDiff;
import com.github.fge.jackson.JsonLoader;
import com.github.fge.jsonschema.main.JsonSchemaFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Service
@PropertySource("classpath:datatypes.properties")
public class SchemaCreatorServiceImpl implements SchemaCreatorService {

    @Autowired
    private SchemaRepository schemaRepository;

    @Autowired
    private DBService dbService;

    @Autowired
    private Environment environment;

    @Autowired
    private Helper helper;

    private List<String> sqls;
    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Override
    public String handleSchemaCreation(String input) {
        JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
        sqls = new ArrayList<>();
        try {
            JsonNode newSchema = JsonLoader.fromString(input);
            if (!factory.getSyntaxValidator().schemaIsValid(newSchema)) {
                throw new InvalidFileFormatException("JSON is not a valid schema!");
            }
            String tableName = newSchema.get("title").textValue();
            if (schemaRepository.existsByTableName(tableName)) {
                JsonNode oldSchema = JsonLoader.fromString(schemaRepository.findByTableName(tableName).getSchema_col());
                compareSchemas(tableName, oldSchema, newSchema);
                dbService.deleteSchema(tableName);
            }
            else {
                createTable(tableName, newSchema);
            }
            dbService.saveSchema(tableName, input);
            return "Schema successfully saved!";
        } catch (IOException exception) {
            throw new InvalidFileFormatException("Couldn't parse input data to JSON!");
        }
    }

    private void createTable(String tableName, JsonNode newSchema) {
        StringBuilder sql = new StringBuilder();
        sql.append("CREATE TABLE ").append(tableName).append(" (");
        JsonNode columns = newSchema.get("items").get("properties");
        Iterator<Map.Entry<String, JsonNode>> fields = columns.fields();
        while (fields.hasNext()) {
            Map.Entry<String, JsonNode> field = fields.next();
            String columnName = field.getKey();
            sql.append(columnName).append(" ");
            sql.append(getDetails(columnName, field.getValue()));
            if (helper.columnIsRequired(columnName, newSchema) || helper.columnIsPrimaryKey(columnName, newSchema)) {
                sql.append(" NOT NULL");
            }
            sql.append(", ");
        }
        sql.append("id SERIAL PRIMARY KEY");
        JsonNode primaryKeys = newSchema.get("items").get("primaryKeys");
        if (primaryKeys != null) {
            sql.append(getPrimaryKeys(primaryKeys));
        }
        JsonNode foreignKeys = newSchema.get("items").get("foreignKeys");
        if (foreignKeys != null) {
            sql.append(getForeignKeys(foreignKeys));
        }
        sql.append(")");
        LOGGER.info("Created sql: " + sql.toString());
        sqls.add(sql.toString());
        dbService.executeSQLs(sqls);
    }

    private String getForeignKeys(JsonNode foreignKeys) {
        StringBuilder sql = new StringBuilder();
        sql.append(", ");
        Iterator<Map.Entry<String, JsonNode>> elements = foreignKeys.fields();
        while (elements.hasNext()) {
            Map.Entry<String, JsonNode> foreignKey = elements.next();
            sql.append("FOREIGN KEY (").append(foreignKey.getKey()).append(") REFERENCES ")
                    .append(foreignKey.getValue().get("table").textValue()).append(" (")
                    .append("id").append("), ");
        }
        sql.delete(sql.length() - 2, sql.length());
        return sql.toString();
    }

    private String getPrimaryKeys(JsonNode primaryKeys) {
        StringBuilder sql = new StringBuilder();
        sql.append(", UNIQUE (");
        Iterator<JsonNode> elements = primaryKeys.elements();
        while (elements.hasNext()) {
            sql.append(elements.next().textValue()).append(",");
        }
        sql.deleteCharAt(sql.length() - 1);
        sql.append(")");
        return sql.toString();
    }

    private void createEnumerator(String columnName, JsonNode enumerator) {
        StringBuilder sql = new StringBuilder();
        sql.append("DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = '")
                .append(columnName)
                .append("') THEN CREATE TYPE ").append(columnName).append(" AS ENUM (");
        Iterator<JsonNode> elements = enumerator.elements();
        while (elements.hasNext()) {
            JsonNode element = elements.next();
            sql.append("'").append(element.textValue()).append("', ");
        }
        sql.delete(sql.length() - 2, sql.length());
        sql.append("); END IF; END $$;");
        LOGGER.info("Created sql: " + sql.toString());
        sqls.add(sql.toString());
    }

    private void compareSchemas(String tableName, JsonNode oldSchema, JsonNode newSchema) {
        JsonNode comparison = JsonDiff.asJson(oldSchema, newSchema);
        if (comparison.size() == 0) {
            throw new SchemaAlreadyExistsException();
        }
        Iterator<JsonNode> changes = comparison.elements();
        while (changes.hasNext()) {
            JsonNode change = changes.next();
            JsonNode path = change.get("path");
            if (path.toString().contains("/items/properties/")) {
                StringBuilder sql = new StringBuilder();
                sql.append("ALTER TABLE ").append(tableName).append(" ");
                String operation = change.get("op").textValue();
                String columnName = path.textValue().replace("/items/properties/", "");
                if (columnName.contains("/")) {
                    throw new InvalidOperationException("Altering columns is not supported (yet)!");
                }
                if (operation.equals("add")) {
                    sql.append("ADD COLUMN ").append(columnName).append(" ");
                    sql.append(getDetails(columnName, change.get("value")));
                    sql.append(handleRequiredColumn(sql.toString(),
                            helper.columnIsRequired(columnName, newSchema) || helper.columnIsPrimaryKey(columnName, newSchema)));
                } else if (operation.equals("remove")) {
                    checkIfForeignKey(oldSchema, columnName);
                    sql.append("DROP COLUMN ").append(columnName);
                } else if (operation.equals("copy")) {
                    sql.append("ADD COLUMN ").append(columnName).append(" ");
                    sql.append(getDetailsFromOldSchema(oldSchema, change.get("from").textValue().replace("/items/properties/", "")));
                    sql.append(handleRequiredColumn(sql.toString(),
                            helper.columnIsRequired(columnName, newSchema) || helper.columnIsPrimaryKey(columnName, newSchema)));
                }
                LOGGER.info("Created sql: " + sql.toString());
                sqls.add(sql.toString());
            }
        }
        dbService.executeSQLs(sqls);
    }

    private void checkIfForeignKey(JsonNode oldSchema, String columnName) {
        JsonNode foreignKeys = oldSchema.get("items").get("foreignKeys");
        if (foreignKeys != null) {
            Iterator<Map.Entry<String, JsonNode>> elements = foreignKeys.fields();
            while (elements.hasNext()) {
                if (elements.next().getKey().equals(columnName)) {
                    throw new InvalidOperationException("Can't remove column if it's a foreign key!");
                }
            }
        }
    }

    private String handleRequiredColumn(String sql, boolean columnIsRequired) {
        if (columnIsRequired) {
            if (!sql.contains(" DEFAULT ")) {
                throw new InvalidOperationException("Can't add not null column to schema without a default value!");
            }
            return " NOT NULL";
        }
        return "";
    }

    private String getDetailsFromOldSchema(JsonNode oldSchema, String columnName) {
        String output = "";
        JsonNode columns = oldSchema.get("items").get("properties");
        Iterator<Map.Entry<String, JsonNode>> fields = columns.fields();
        while (fields.hasNext()) {
            Map.Entry<String, JsonNode> field = fields.next();
            String newColumnName = field.getKey();
            if (newColumnName.equals(columnName)) {
                output = getDetails(columnName, field.getValue());
            }
        }
        return output;
    }

    private String getDetails(String columnName, JsonNode jsonNode) {
        StringBuilder output = new StringBuilder();
        Iterator<Map.Entry<String, JsonNode>> details = jsonNode.fields();
        while (details.hasNext()) {
            Map.Entry<String, JsonNode> detail = details.next();
            if (detail.getKey().equals("type")) {
                if (detail.getValue().isArray()) {
                    if (detail.getValue().get(0).textValue().toLowerCase().equals("null")) {
                        throw new InvalidOperationException(columnName + " column's main type can't be null!");
                    }
                    if (detail.getValue().size() > 2) {
                        throw new InvalidOperationException(columnName + " column can't have multiple types!");
                    }
                    if (detail.getValue().size() == 2 && !detail.getValue().get(1).textValue().toLowerCase().equals("null")) {
                        throw new InvalidOperationException(columnName + " column can't have multiple types!");
                    }
                    output.append(environment.getProperty(detail.getValue().get(0).textValue().toLowerCase()));
                }
                else {
                    output.append(environment.getProperty(detail.getValue().textValue().toLowerCase()));
                }
            }
            if (detail.getKey().equals("enum")) {
                createEnumerator(columnName, detail.getValue());
                output.append(columnName);
            }
            if (detail.getKey().equals("default")) {
                output.append(" DEFAULT ");
                if (detail.getValue().toString().equals("\"now()\"")) {
                    output.append(detail.getValue().textValue());
                }
                else {
                    output.append(detail.getValue().toString().replace('\"', '\''));
                }
            }
            if (detail.getKey().equals("unique") && detail.getValue().booleanValue()) {
                output.append(" UNIQUE");
            }
        }
        return output.toString();
    }

}
