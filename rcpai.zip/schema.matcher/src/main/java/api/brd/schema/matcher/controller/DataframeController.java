package api.brd.schema.matcher.controller;

import api.brd.schema.matcher.service.DataFrameService;
import api.brd.schema.matcher.service.MatcherService;
import api.brd.schema.matcher.service.SchemaCreatorService;
import api.brd.schema.matcher.view.DefineSchemaView;
import com.github.fge.jackson.JsonLoader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.io.IOException;

@Controller
public class DataframeController {

    @Autowired
    private DataFrameService dataframeService;

    @Autowired
    private SchemaCreatorService schemaCreatorService;

    @Autowired
    private MatcherService matcherService;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String index() {
        return "index";
    }

    @RequestMapping(value = "/dataframe", method = RequestMethod.POST, consumes = "multipart/form-data")
    public ModelAndView handleInputData(@RequestParam("threshold") Double threshold, @RequestParam("file") MultipartFile multipartFile, HttpSession session) {
        DefineSchemaView view = dataframeService.handleDataFrameCreation(threshold, multipartFile, session);
        if (view == null) {
            return new ModelAndView("success", "message", "Data was successfully inserted!");
        }
        else {
            return new ModelAndView("define_schema", "view", view);
        }
    }

    @RequestMapping(value = "/dataframe/settings", method = RequestMethod.POST)
    public ModelAndView handleInputData(@RequestParam("schema") String schema, HttpSession session) throws IOException {
        schemaCreatorService.handleSchemaCreation(schema);
        matcherService.handleInsertion(String.valueOf(session.getAttribute("data")), JsonLoader.fromString(schema));
        return new ModelAndView("success", "message", "Schema successfully saved and data successfully inserted!");
    }

}
