package api.brd.schema.matcher.service;

import api.brd.schema.matcher.view.DefineSchemaView;
import org.springframework.web.multipart.MultipartFile;
import tech.tablesaw.api.Table;

import javax.servlet.http.HttpSession;
import java.util.Map;

public interface DataFrameService {

    Map<String, Double> calculateMissingRowPercentage(Table table);

    Table removeColumnsAboveThreshold(Table table, Map<String, Double> nullPercentages, Double threshold);

    DefineSchemaView handleDataFrameCreation(Double threshold, MultipartFile multipartFile, HttpSession session);

    String createSchema(Table table);

    String createJson(Table table);

    String createReducedJson(Double threshold, Table table);

    String getFileExtension(String fileName);

    DefineSchemaView createView(Table table);

}
