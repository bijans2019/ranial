package api.brd.schema.matcher.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class SchemaAlreadyExistsException extends ResponseStatusException {

    private static final HttpStatus STATUS = HttpStatus.BAD_REQUEST;
    private static final String REASON = "Schema with same details already exists for this table!";

    public SchemaAlreadyExistsException() {
        super(STATUS, REASON);
    }

}
