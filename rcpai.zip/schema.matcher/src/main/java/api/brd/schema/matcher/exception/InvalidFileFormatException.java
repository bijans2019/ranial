package api.brd.schema.matcher.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class InvalidFileFormatException extends ResponseStatusException {

    private static final HttpStatus STATUS = HttpStatus.BAD_REQUEST;

    public InvalidFileFormatException(String reason) {
        super(STATUS, reason);
    }

}
