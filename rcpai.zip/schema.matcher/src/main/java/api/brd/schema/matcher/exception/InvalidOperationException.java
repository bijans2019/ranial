package api.brd.schema.matcher.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class InvalidOperationException extends ResponseStatusException {

    private static final HttpStatus STATUS = HttpStatus.BAD_REQUEST;

    public InvalidOperationException(String reason) {
        super(STATUS, reason);
    }

}
