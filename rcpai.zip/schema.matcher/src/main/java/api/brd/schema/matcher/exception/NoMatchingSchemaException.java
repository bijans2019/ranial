package api.brd.schema.matcher.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class NoMatchingSchemaException extends ResponseStatusException {

    private static final HttpStatus STATUS = HttpStatus.INTERNAL_SERVER_ERROR;
    private static final String REASON = "Couldn't find a matching schema!";

    public NoMatchingSchemaException() {
        super(STATUS, REASON);
    }

}
