package api.brd.schema.matcher.repository;

import api.brd.schema.matcher.entity.Schema;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SchemaRepository extends JpaRepository<Schema, Integer> {

    boolean existsByTableName(String tableName);

    Schema findByTableName(String tableName);

}
