package api.brd.schema.matcher.service;

import com.fasterxml.jackson.databind.JsonNode;

public interface MatcherService {

    JsonNode findMatchingSchema(String inputData);

    String handleInsertion(String inputData, JsonNode schema);

}
