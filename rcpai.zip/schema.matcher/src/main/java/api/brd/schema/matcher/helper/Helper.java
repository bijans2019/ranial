package api.brd.schema.matcher.helper;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Service;

import java.util.Iterator;

@Service
public class Helper {

    public boolean columnIsRequired(String columnName, JsonNode schema) {
        JsonNode required = schema.get("items").get("required");
        if (required != null) {
            Iterator<JsonNode> elements = required.elements();
            while (elements.hasNext()) {
                if (elements.next().textValue().equals(columnName)) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean columnIsPrimaryKey(String columnName, JsonNode schema) {
        JsonNode primaryKeys = schema.get("items").get("primaryKeys");
        if (primaryKeys != null) {
            Iterator<JsonNode> elements = primaryKeys.elements();
            while (elements.hasNext()) {
                if (elements.next().textValue().equals(columnName)) {
                    return true;
                }
            }
        }
        return false;
    }

}
