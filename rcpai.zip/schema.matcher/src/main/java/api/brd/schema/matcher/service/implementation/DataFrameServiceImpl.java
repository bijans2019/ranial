package api.brd.schema.matcher.service.implementation;

import api.brd.schema.matcher.exception.InvalidFileFormatException;
import api.brd.schema.matcher.exception.InvalidOperationException;
import api.brd.schema.matcher.exception.NoMatchingSchemaException;
import api.brd.schema.matcher.helper.LocalDateDeserializer;
import api.brd.schema.matcher.helper.LocalDateSerializer;
import api.brd.schema.matcher.service.DataFrameService;
import api.brd.schema.matcher.service.MatcherService;
import api.brd.schema.matcher.view.DefineSchemaView;
import api.brd.schema.matcher.view.SchemaColumn;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import tech.tablesaw.api.Table;
import tech.tablesaw.columns.Column;
import tech.tablesaw.io.Source;
import tech.tablesaw.io.json.JsonReader;
import tech.tablesaw.io.xlsx.XlsxReader;

import javax.servlet.http.HttpSession;
import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class DataFrameServiceImpl implements DataFrameService {

    @Autowired
    private MatcherService matcherService;

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Override
    public Map<String, Double> calculateMissingRowPercentage(Table table) {
        return table.columns().stream().collect(Collectors.toMap(Column::name, c -> (double) c.countMissing() / c.size() * 100));
    }

    @Override
    public Table removeColumnsAboveThreshold(Table table, Map<String, Double> nullPercentages, Double threshold) {
        List<String> removable = new ArrayList<>();
        table.columns().forEach(c -> {
            if (nullPercentages.get(c.name()) > threshold) {
                removable.add(c.name());
            }
        });
        table.removeColumns(removable.toArray(new String[0]));
        return table;
    }

    @Override
    public DefineSchemaView handleDataFrameCreation(Double threshold, MultipartFile multipartFile, HttpSession session) {
        try {
            Table table;
            InputStream inputStream = new ByteArrayInputStream(multipartFile.getBytes());
            switch (getFileExtension(Objects.requireNonNull(multipartFile.getOriginalFilename()))) {
                case "csv": table = Table.read().csv(inputStream); break;
                case "xlsx": table = new XlsxReader().read(new Source(inputStream)); break;
                case "json": table = new JsonReader().read(new Source(inputStream)); break;
                default: throw new InvalidFileFormatException("Unsupported file extension!");
            }
            LOGGER.info("Initial schema: " + createSchema(table));
            LOGGER.info("Initial table:");
            LOGGER.info(table.print());
            JsonNode schema;
            String json = createReducedJson(threshold, table);
            try {
                schema = matcherService.findMatchingSchema(json);
                matcherService.handleInsertion(json, schema);
                return null;
            }
            catch (NoMatchingSchemaException e) {
                session.setAttribute("data", json);
                return createView(table);
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw new InvalidOperationException("Unable to write or read file in system!");
        }
    }

    @Override
    public DefineSchemaView createView(Table table) {
        DefineSchemaView view = new DefineSchemaView();
        view.setSchema(createSchema(table));
        view.setColumns(table.columns().stream().map(c -> new SchemaColumn(c.name(), getSchemaFieldType(c.type().getPrinterFriendlyName()))).collect(Collectors.toList()));
        return view;
    }

    @Override
    public String createReducedJson(Double threshold, Table table) {
        Map<String, Double> numberOfNulls = calculateMissingRowPercentage(table);
        table = removeColumnsAboveThreshold(table, numberOfNulls, threshold);
        String json = createJson(table);
        LOGGER.info("Schema after removing columns above " + threshold + "% of null fields: " + createSchema(table));
        LOGGER.info("Table after removing columns above " + threshold + "% of null fields:");
        LOGGER.info(table.print());
        LOGGER.info("Json created from table's rows: " + json);
        return json;
    }

    @Override
    public String createSchema(Table table) {
        StringBuilder jsonSchema = new StringBuilder();
        jsonSchema.append("{\"type\": \"array\", ")
                .append("\"items\": { ")
                .append("\"type\": \"object\", ")
                .append("\"properties\": { ");
        table.columns().forEach(c -> jsonSchema.append("\"")
                .append(c.name())
                .append("\": { \"type\": [ \"")
                .append(getSchemaFieldType(c.type().getPrinterFriendlyName()))
                .append("\" , \"null\" ] }, "));
        jsonSchema.delete(jsonSchema.length() - 2, jsonSchema.length());
        jsonSchema.append(" }, ")
                .append("\"required\": [], ")
                .append("\"primaryKeys\": [] ")
                .append("} }");
        return jsonSchema.toString();
    }

    @Override
    public String createJson(Table table) {
        ObjectMapper mapper = new ObjectMapper();
        JavaTimeModule javaTimeModule = new JavaTimeModule();
        javaTimeModule.addSerializer(LocalDate.class, new LocalDateSerializer());
        javaTimeModule.addDeserializer(LocalDate.class, new LocalDateDeserializer());
        mapper.registerModule(javaTimeModule);
        ArrayNode array = mapper.createArrayNode();
        for (int i = 0; i < table.rowCount(); ++i) {
            ObjectNode element = mapper.createObjectNode();
            for (int j = 0; j < table.columnCount(); ++j) {
                Column currentColumn = table.column(j);
                if (!currentColumn.isMissing(i)) {
                    element.putPOJO(currentColumn.name(), currentColumn.get(i));
                }
                else {
                    element.putNull(currentColumn.name());
                }
            }
            array.add(element);
        }
        try {
            return mapper.writeValueAsString(array);
        } catch (JsonProcessingException e) {
            throw new InvalidFileFormatException("Couldn't parse input to JSON!");
        }
    }


    private String getSchemaFieldType(String typeName) {
        switch (typeName) {
            case "Short":
            case "Integer" : return "integer";
            case "Float":
            case "Double":
            case "Long": return "number";
            case "Boolean": return "boolean";
            default: return "string";
        }
    }

    @Override
    public String getFileExtension(String fileName) {
        int index = fileName.lastIndexOf('.');
        if (index > 0) {
            return fileName.substring(index + 1);
        }
        throw new InvalidFileFormatException("File doesn't have an extension!");
    }

}
