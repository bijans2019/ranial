package api.brd.schema.matcher.entity;

import javax.persistence.*;

@Entity(name = "schemas_e")
public class Schema {

    @Id
    @SequenceGenerator(name = "pk_sequence", sequenceName = "schemas_id_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pk_sequence")
    @Column(name = "id", unique = true, nullable = false)
    private int id;

    @Column(name = "table_name", unique = true)
    private String tableName;

    @Column(name = "schema_col")
    private String schema_col;

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getSchema_col() {
        return schema_col;
    }

    public void setSchema_col(String schema) {
        this.schema_col = schema;
    }

}
