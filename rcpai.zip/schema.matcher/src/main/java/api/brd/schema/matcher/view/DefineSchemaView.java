package api.brd.schema.matcher.view;

import java.util.List;

public class DefineSchemaView {

    private String schema;
    private List<SchemaColumn> columns;

    public String getSchema() {
        return schema;
    }

    public void setSchema(String schema) {
        this.schema = schema;
    }

    public List<SchemaColumn> getColumns() {
        return columns;
    }

    public void setColumns(List<SchemaColumn> columns) {
        this.columns = columns;
    }

}
