package api.brd.schema.matcher.controller;

import api.brd.schema.matcher.service.MatcherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MatcherController {

    @Autowired
    private MatcherService matcherService;

    @RequestMapping(value = "/data", method = RequestMethod.POST)
    public String matchToSchemas(@RequestBody String inputData) {
        return matcherService.handleInsertion(inputData, matcherService.findMatchingSchema(inputData));
    }

}
