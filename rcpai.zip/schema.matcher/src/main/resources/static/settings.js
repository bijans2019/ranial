$(document).ready(function () {
    var schema = JSON.parse($("#schema").html());
    $("#schema").html(JSON.stringify(schema, null, 2));

    $("input").change(function() {
        var type = $(this).attr("name");
        var name = $(this).attr("data-columnname");
        var value = $(this).val();
        switch (type) {
            case "unique":
                if ($(this).is(":checked")) {
                    schema.items.properties[name][type] = true;
                }
                else {
                    delete schema.items.properties[name][type]
                }
                break;
            case "primary":
                if ($(this).is(":checked")) {
                    schema.items.primaryKeys.push(name);
                }
                else {
                    var index = schema.items.primaryKeys.findIndex(x => x == name);
                    schema.items.primaryKeys.splice(index, 1);
                }
                break;
            case "required":
                if ($(this).is(":checked")) {
                    schema.items.required.push(name);
                    var index = schema.items.properties[name].type.findIndex(x => x == "null");
                    schema.items.properties[name].type.splice(index, 1);
                }
                else {
                    var index = schema.items.required.findIndex(x => x == name);
                    schema.items.required.splice(index, 1);
                    schema.items.properties[name].type.push("null");
                }
                break;
            case "default":
                if (value != "") {
                    setDefaultValue(schema, name, type, value);
                }
                else {
                    delete schema.items.properties[name][type];
                }
                break;
            case "title":
                if (value != "") {
                    schema[type] = value;
                }
                else {
                    delete schema[type];
                }
                break;
            default:
                if (value != "") {
                    schema.items.properties[name][type] = parseInt(value);
                }
                else {
                    delete schema.items.properties[name][type];
                }
        }
        $("#schema").html(JSON.stringify(schema, null, 2));
    });

    $("#submit").click(function() {
        if ($("#title").val() == "") {
            window.alert("Please specify the table's name!");
        }
        else if (Object.keys(schema.items.required).length == 0 || Object.keys(schema.items.primaryKeys).length == 0) {
            window.alert("Please specify at least one required and one primary key field!");
        }
        else {
            post("/dataframe/settings", "post", JSON.stringify(schema, null, 2));
        }
    });

});

function setDefaultValue(schema, name, type, value) {
    switch(schema.items.properties[name].type[0]) {
        case "integer":
        case "number":
            if (!isNaN(value)) {
                schema.items.properties[name][type] = parseInt(value);
            }
            else {
                window.alert("Default value must be a number!");
            }
            break;
        case "boolean":
            if (value == "true" || value == "false") {
                (value == "true") ? schema.items.properties[name][type] = true : schema.items.properties[name][type] = false;
            }
            else {
                window.alert("Default value must be either 'true' or 'false'!");
            }
            break;
        default:
            schema.items.properties[name][type] = value;
    }
}

function post(path, method, schema) {
    var form = document.createElement("form");
    form.setAttribute("method", method);
    form.setAttribute("action", path);
    createHiddenField(form, "schema", schema);
    document.body.appendChild(form);
    form.submit();
}

function createHiddenField(form, name, schema) {
    var hiddenField = document.createElement("input");
    hiddenField.setAttribute("type", "hidden");
    hiddenField.setAttribute("name", name);
    hiddenField.setAttribute("value", schema);
    form.appendChild(hiddenField);
}
