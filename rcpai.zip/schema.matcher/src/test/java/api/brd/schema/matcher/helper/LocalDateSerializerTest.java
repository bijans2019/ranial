package api.brd.schema.matcher.helper;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;

import javax.swing.plaf.basic.BasicDesktopIconUI;

import java.io.IOException;
import java.time.LocalDate;

import static org.junit.Assert.*;

public class LocalDateSerializerTest {

    @InjectMocks
    private LocalDateSerializer localDateSerializer;

    @Mock
    private JsonGenerator jsonGenerator;

    @Mock
    private SerializerProvider serializerProvider;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void serialize() throws IOException {
        // WHEN
        localDateSerializer.serialize(LocalDate.of(2019,8, 7), jsonGenerator, serializerProvider);

        // THEN
        BDDMockito.verify(jsonGenerator, Mockito.times(1)).writeString("2019/08/07");
        BDDMockito.verifyNoMoreInteractions(jsonGenerator);
    }

}
