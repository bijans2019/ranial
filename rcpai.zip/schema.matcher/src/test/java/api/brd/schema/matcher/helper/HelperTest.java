package api.brd.schema.matcher.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class HelperTest {

    @InjectMocks
    private Helper helper;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void columnIsRequired() {
        String columnName = "testColumnName";
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode schema = mapper.createObjectNode();
        ObjectNode properties = mapper.createObjectNode();
        ObjectNode items = mapper.createObjectNode();
        ArrayNode required = mapper.createArrayNode();
        required.add(columnName);
        required.add("test");
        items.putArray("required").addAll(required);
        schema.set("items", items);
        schema.set("properties", properties);

        // WHEN
        boolean actual = helper.columnIsRequired(columnName, schema);

        // THEN
        Assert.assertTrue(actual);
    }

    @Test
    public void columnIsNotRequired() {
        String columnName = "testColumnName";
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode schema = mapper.createObjectNode();
        ObjectNode properties = mapper.createObjectNode();
        ObjectNode items = mapper.createObjectNode();
        items.putArray("required");
        schema.set("items", items);
        schema.set("properties", properties);

        // WHEN
        boolean actual = helper.columnIsRequired(columnName, schema);

        // THEN
        Assert.assertFalse(actual);
    }

    @Test
    public void columnIsPrimaryKey() {
        String columnName = "testColumnName";
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode schema = mapper.createObjectNode();
        ObjectNode properties = mapper.createObjectNode();
        ObjectNode items = mapper.createObjectNode();
        ArrayNode primaryKeys = mapper.createArrayNode();
        primaryKeys.add(columnName);
        primaryKeys.add("test");
        items.putArray("primaryKeys").addAll(primaryKeys);
        schema.set("items", items);
        schema.set("properties", properties);

        // WHEN
        boolean actual = helper.columnIsPrimaryKey(columnName, schema);

        // THEN
        Assert.assertTrue(actual);
    }

    @Test
    public void columnIsNotPrimaryKey() {
        String columnName = "testColumnName";
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode schema = mapper.createObjectNode();
        ObjectNode properties = mapper.createObjectNode();
        ObjectNode items = mapper.createObjectNode();
        items.putArray("primaryKeys");
        schema.set("items", items);
        schema.set("properties", properties);

        // WHEN
        boolean actual = helper.columnIsPrimaryKey(columnName, schema);

        // THEN
        Assert.assertFalse(actual);
    }

}
