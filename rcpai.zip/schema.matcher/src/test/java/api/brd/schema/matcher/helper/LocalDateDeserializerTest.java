package api.brd.schema.matcher.helper;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.io.IOException;
import java.time.LocalDate;

public class LocalDateDeserializerTest {

    @InjectMocks
    private LocalDateDeserializer localDateDeserializer;

    @Mock
    private JsonParser jsonParser;

    @Mock
    private DeserializationContext deserializationContext;

    @Before
    public void setUp()  {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void deserialize() throws IOException {
        // GIVEN
        BDDMockito.when(jsonParser.getValueAsString()).thenReturn("2019/08/07");

        // WHEN
        LocalDate actual = localDateDeserializer.deserialize(jsonParser, deserializationContext);

        // THEN
        Assert.assertEquals(LocalDate.of(2019,8, 7), actual);
    }

}
