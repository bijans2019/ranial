package api.brd.schema.matcher.service;

import api.brd.schema.matcher.entity.Schema;
import api.brd.schema.matcher.repository.SchemaRepository;
import api.brd.schema.matcher.service.implementation.DBServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;

import static org.junit.Assert.assertEquals;

public class DBServiceTest {

    @InjectMocks
    private DBService dbService = new DBServiceImpl();

    @Mock
    private SchemaRepository schemaRepository;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void removeSchema() {
        // GIVEN
        String tableName = "test";
        Schema schema = new Schema();
        Mockito.when(schemaRepository.findByTableName(tableName)).thenReturn(schema);

        // WHEN
        dbService.deleteSchema(tableName);

        // THEN
        Mockito.verify(schemaRepository).delete(schema);
    }

    @Test
    public void saveSchema() {
        // GIVEN
        String tableName = "test";
        String input = "testInput";
        ArgumentCaptor<Schema> argument = ArgumentCaptor.forClass(Schema.class);

        // WHEN
        dbService.saveSchema(tableName, input);

        // THEN
        Mockito.verify(schemaRepository).save(argument.capture());
        assertEquals(tableName, argument.getValue().getTableName());
        assertEquals(input, argument.getValue().getSchema_col());
    }

}
