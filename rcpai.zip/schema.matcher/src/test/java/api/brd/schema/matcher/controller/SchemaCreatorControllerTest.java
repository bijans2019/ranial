package api.brd.schema.matcher.controller;

import api.brd.schema.matcher.service.SchemaCreatorService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(SchemaCreatorController.class)
public class SchemaCreatorControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private SchemaCreatorService service;

    @Test
    public void createSchema() throws Exception {
        // GIVEN
        String input = "testInput";
        String expected = "Schema successfully saved!";
        Mockito.when(service.handleSchemaCreation(input)).thenReturn(expected);

        // WHEN
        String actual = mvc.perform(post("/schema")
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .content(input))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();

        // THEN
        Assert.assertEquals(expected, actual);
    }

}
