package api.brd.schema.matcher.service;

import api.brd.schema.matcher.exception.InvalidFileFormatException;
import api.brd.schema.matcher.service.implementation.DataFrameServiceImpl;
import api.brd.schema.matcher.view.DefineSchemaView;
import api.brd.schema.matcher.view.SchemaColumn;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import tech.tablesaw.api.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class DataFrameServiceTest {

    @InjectMocks
    private DataFrameService dataFrameService = new DataFrameServiceImpl();

    private Table table = createExpectedTable();
    private String schema = createExpectedSchema();


    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    private String createExpectedSchema() {
        return  "{\"type\": \"array\", \"items\": " +
                "{ \"type\": \"object\", \"properties\": { " +
                "\"booleans\": { \"type\": [ \"boolean\" , \"null\" ] }, " +
                "\"name\": { \"type\": [ \"string\" , \"null\" ] }, " +
                "\"age\": { \"type\": [ \"integer\" , \"null\" ] }, " +
                "\"date_of_birth\": { \"type\": [ \"string\" , \"null\" ] }, " +
                "\"doubles\": { \"type\": [ \"number\" , \"null\" ] } }, " +
                "\"required\": [], \"primaryKeys\": [] } }";
    }

    private Table createExpectedTable() {
        BooleanColumn booleans = BooleanColumn.create("booleans");
        booleans.append(true).append(false).appendMissing().appendMissing();
        StringColumn name = StringColumn.create("name");
        name.append("bela").append("sandor").append("janos").append("gergo");
        IntColumn age = IntColumn.create("age");
        age.append(3).append(4).appendMissing().append(5);
        DateColumn dateOfBirth = DateColumn.create("date_of_birth");
        dateOfBirth.appendMissing().appendMissing().appendMissing().append(LocalDate.now());
        DoubleColumn doubles = DoubleColumn.create("doubles", 4);
        return Table.create("employees").addColumns(booleans, name, age, dateOfBirth, doubles);
    }

    @Test
    public void calculateMissingRowPercentage() {
        // WHEN
        Map<String, Double> actual = dataFrameService.calculateMissingRowPercentage(table);

        // THEN
        assertEquals(new Double(0), actual.get("name"));
        assertEquals(new Double(25), actual.get("age"));
        assertEquals(new Double(50), actual.get("booleans"));
        assertEquals(new Double(75), actual.get("date_of_birth"));
        assertEquals(new Double(100), actual.get("doubles"));
    }

    @Test
    public void removeColumnsAboveThreshold() {
        Map<String, Double> nullPercentages = new HashMap<>();
        nullPercentages.put("name", 0.0);
        nullPercentages.put("age", 25.0);
        nullPercentages.put("booleans", 50.0);
        nullPercentages.put("date_of_birth", 75.0);
        nullPercentages.put("doubles", 100.0);

        // WHEN
        Table actual = dataFrameService.removeColumnsAboveThreshold(table, nullPercentages, 30.0);

        // THEN
        assertEquals(2, actual.columnCount());
        assertTrue(table.columnNames().contains("name"));
        assertTrue(table.columnNames().contains("age"));
    }

    @Test
    public void handleDataFrameCreation() {
    }

    @Test
    public void createSchema() {
        // WHEN
        String actual = dataFrameService.createSchema(table);

        // THEN
        assertEquals(schema, actual);
    }

    @Test
    public void createJson() {
        // WHEN
        String actual = dataFrameService.createJson(table);

        // THEN
        String expected = "[{\"booleans\":true,\"name\":\"bela\",\"age\":3,\"date_of_birth\":null,\"doubles\":null}," +
                "{\"booleans\":false,\"name\":\"sandor\",\"age\":4,\"date_of_birth\":null,\"doubles\":null}," +
                "{\"booleans\":null,\"name\":\"janos\",\"age\":null,\"date_of_birth\":null,\"doubles\":null}," +
                "{\"booleans\":null,\"name\":\"gergo\",\"age\":5,\"date_of_birth\":\"2019/08/12\",\"doubles\":null}]";
        assertEquals(expected, actual);
    }

    @Test
    public void createReducedJsonWithThreeColumns() {
        // WHEN
        String actual = dataFrameService.createReducedJson(50.0, table);

        // THEN
        String expected = "[{\"booleans\":true,\"name\":\"bela\",\"age\":3}," +
                "{\"booleans\":false,\"name\":\"sandor\",\"age\":4}," +
                "{\"booleans\":null,\"name\":\"janos\",\"age\":null}," +
                "{\"booleans\":null,\"name\":\"gergo\",\"age\":5}]";
        assertEquals(expected, actual);
    }

    @Test
    public void createReducedJsonWithTwoColumns() {
        // WHEN
        String actual = dataFrameService.createReducedJson(49.99, table);

        // THEN
        String expected = "[{\"name\":\"bela\",\"age\":3}," +
                "{\"name\":\"sandor\",\"age\":4}," +
                "{\"name\":\"janos\",\"age\":null}," +
                "{\"name\":\"gergo\",\"age\":5}]";
        assertEquals(expected, actual);
    }

    @Test
    public void createView() {
        // WHEN
        DefineSchemaView actual = dataFrameService.createView(table);

        // THEN
        assertEquals(schema, actual.getSchema());
        List<SchemaColumn> expectedColumns = new ArrayList<>();
        expectedColumns.add(new SchemaColumn("name", "string"));
        expectedColumns.add(new SchemaColumn("booleans", "boolean"));
        expectedColumns.add(new SchemaColumn("age", "integer"));
        expectedColumns.add(new SchemaColumn("date_of_birth", "string"));
        expectedColumns.add(new SchemaColumn("doubles", "number"));
        Assertions.assertThat(actual.getColumns()).containsAll(expectedColumns);
    }

    @Test
    public void getFileExtension() {
        // WHEN
        String actual = dataFrameService.getFileExtension("test.csv");

        // THEN
        assertEquals("csv", actual);
    }

    @Test(expected = InvalidFileFormatException.class)
    public void missingFileExtension() {
        // WHEN
        dataFrameService.getFileExtension("test");
    }

}
