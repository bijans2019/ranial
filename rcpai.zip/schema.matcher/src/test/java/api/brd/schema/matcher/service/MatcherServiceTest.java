package api.brd.schema.matcher.service;

import api.brd.schema.matcher.entity.Schema;
import api.brd.schema.matcher.exception.InvalidFileFormatException;
import api.brd.schema.matcher.exception.NoMatchingSchemaException;
import api.brd.schema.matcher.helper.Helper;
import api.brd.schema.matcher.repository.SchemaRepository;
import api.brd.schema.matcher.service.implementation.MatcherServiceImpl;
import com.fasterxml.jackson.databind.JsonNode;
import com.github.fge.jackson.JsonLoader;
import com.google.common.base.Charsets;
import com.google.common.io.Resources;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;

import java.io.IOException;
import java.net.URL;
import java.util.Collections;

public class MatcherServiceTest {

    @InjectMocks
    private MatcherService matcherService = new MatcherServiceImpl();

    @Mock
    private SchemaRepository schemaRepository;

    @Mock
    private DBService dbService;

    @Spy
    private Helper helper;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test(expected = InvalidFileFormatException.class)
    public void wrongJsonFormat() {
        // WHEN
        matcherService.findMatchingSchema("");
    }

    @Test(expected = NoMatchingSchemaException.class)
    public void noMatchingSchema() throws IOException {
        // GIVEN
        URL noMatchInputData = Resources.getResource("inputData/matchBaseTable.json");
        String inputData = Resources.toString(noMatchInputData, Charsets.UTF_8);
        Mockito.when(schemaRepository.findAll()).thenReturn(Collections.emptyList());

        // WHEN
        matcherService.findMatchingSchema(inputData);
    }

    @Test(expected = InvalidFileFormatException.class)
    public void wrongJsonSchemaFormat() throws IOException {
        // GIVEN
        URL matchBaseInputData = Resources.getResource("inputData/matchBaseTable.json");
        String inputData = Resources.toString(matchBaseInputData, Charsets.UTF_8);
        URL wrongJsonSchema = Resources.getResource("schemas/wrongJsonSchema.json");
        String input = Resources.toString(wrongJsonSchema, Charsets.UTF_8);
        Schema schema = new Schema();
        schema.setTableName("test");
        schema.setSchema(input);
        Mockito.when(schemaRepository.findAll()).thenReturn(Collections.singletonList(schema));

        // WHEN
        matcherService.findMatchingSchema(inputData);
    }

    @Test
    public void handleInsertion() throws IOException {
        // GIVEN
        String tableName = "test";
        URL matchBaseInputData = Resources.getResource("inputData/matchBaseTable.json");
        String inputData = Resources.toString(matchBaseInputData, Charsets.UTF_8);
        URL createTableSchema = Resources.getResource("schemas/createTable.json");
        String input = Resources.toString(createTableSchema, Charsets.UTF_8);

        // WHEN
        String actual = matcherService.handleInsertion(inputData, JsonLoader.fromString(input));

        // THEN
        String expectedSql = "INSERT INTO " + tableName + " (name, age) VALUES ('Bela', 20), ('Sanyi', 30) ON CONFLICT ON CONSTRAINT " + tableName + "_name_key DO UPDATE SET age = Excluded.age";
        Mockito.verify(dbService).executeSQLs(Collections.singletonList(expectedSql));
        String expected = "Data successfully inserted into table '" + tableName + "'!";
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void findMatchingSchema() throws IOException {
        // GIVEN
        String tableName = "test";
        URL matchBaseInputData = Resources.getResource("inputData/matchBaseTable.json");
        String inputData = Resources.toString(matchBaseInputData, Charsets.UTF_8);
        URL createTableSchema = Resources.getResource("schemas/createTable.json");
        String input = Resources.toString(createTableSchema, Charsets.UTF_8);
        Schema schema = new Schema();
        schema.setTableName(tableName);
        schema.setSchema(input);
        Mockito.when(schemaRepository.findAll()).thenReturn(Collections.singletonList(schema));

        // WHEN
        JsonNode actual = matcherService.findMatchingSchema(inputData);

        // THEN
        Assert.assertEquals(JsonLoader.fromString(input), actual);
    }

}
