package api.brd.schema.matcher.service;

import api.brd.schema.matcher.entity.Schema;
import api.brd.schema.matcher.exception.InvalidFileFormatException;
import api.brd.schema.matcher.exception.InvalidOperationException;
import api.brd.schema.matcher.exception.SchemaAlreadyExistsException;
import api.brd.schema.matcher.helper.Helper;
import api.brd.schema.matcher.repository.SchemaRepository;
import api.brd.schema.matcher.service.implementation.SchemaCreatorServiceImpl;
import com.google.common.base.Charsets;
import com.google.common.io.Resources;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;
import org.springframework.core.env.Environment;

import java.io.IOException;
import java.net.URL;
import java.util.List;

public class SchemaCreatorServiceTest {

    @InjectMocks
    private SchemaCreatorService schemaCreatorService = new SchemaCreatorServiceImpl();

    @Mock
    private SchemaRepository schemaRepository;

    @Mock
    private DBService dbService;

    @Mock
    private Environment environment;

    @Spy
    private Helper helper;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        Mockito.when(environment.getProperty("string")).thenReturn("VARCHAR");
        Mockito.when(environment.getProperty("integer")).thenReturn("INT");
        Mockito.when(environment.getProperty("boolean")).thenReturn("BOOL");
        Mockito.when(environment.getProperty("number")).thenReturn("FLOAT8");
    }

    @Test
    public void tableCreation() throws IOException {
        // GIVEN
        String tableName = "test";
        URL createTableSchema = Resources.getResource("schemas/createTable.json");
        String input = Resources.toString(createTableSchema, Charsets.UTF_8);
        Mockito.when(schemaRepository.existsByTableName(tableName)).thenReturn(false);

        // WHEN
        String actual = schemaCreatorService.handleSchemaCreation(input);

        // THEN
        String firstExpectedSql = "DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'gender') THEN CREATE TYPE gender AS ENUM ('Male', 'Female'); END IF; END $$;";
        String secondExpectedSql = "CREATE TABLE " + tableName +
                " (name VARCHAR NOT NULL, age INT DEFAULT 16 NOT NULL, join_date VARCHAR DEFAULT now() UNIQUE, exact_join_date VARCHAR DEFAULT now()," +
                " happy BOOL DEFAULT true, gender gender, id SERIAL PRIMARY KEY, UNIQUE (name), FOREIGN KEY (join_date) REFERENCES other_test (id))";
        ArgumentCaptor<List> argument = ArgumentCaptor.forClass(List.class);
        Mockito.verify(dbService).executeSQLs(argument.capture());
        Assert.assertEquals(firstExpectedSql, argument.getValue().get(0));
        Assert.assertEquals(secondExpectedSql, argument.getValue().get(1));
        String expectedResponse = "Schema successfully saved!";
        Assert.assertEquals(expectedResponse, actual);
    }

    @Test
    public void addColumn() throws IOException {
        // GIVEN
        String tableName = "test";
        URL createTableSchema = Resources.getResource("schemas/createTable.json");
        String existingSchema = Resources.toString(createTableSchema, Charsets.UTF_8);
        Mockito.when(schemaRepository.existsByTableName(tableName)).thenReturn(true);
        Schema schema = new Schema();
        schema.setSchema(existingSchema);
        schema.setTableName(tableName);
        Mockito.when(schemaRepository.findByTableName(tableName)).thenReturn(schema);
        URL addColumnSchema = Resources.getResource("schemas/addColumn.json");
        String newSchema = Resources.toString(addColumnSchema, Charsets.UTF_8);

        // WHEN
        String actual = schemaCreatorService.handleSchemaCreation(newSchema);

        // THEN
        String expectedSql = "ALTER TABLE " + tableName + " ADD COLUMN city VARCHAR DEFAULT 'Budapest' NOT NULL";
        ArgumentCaptor<List> argument = ArgumentCaptor.forClass(List.class);
        Mockito.verify(dbService).executeSQLs(argument.capture());
        Assert.assertEquals(argument.getValue().get(0), expectedSql);
        String expectedResponse = "Schema successfully saved!";
        Assert.assertEquals(expectedResponse, actual);
    }

    @Test
    public void removeColumn() throws IOException {
        // GIVEN
        String tableName = "test";
        URL createTableSchema = Resources.getResource("schemas/createTable.json");
        String existingSchema = Resources.toString(createTableSchema, Charsets.UTF_8);
        Mockito.when(schemaRepository.existsByTableName(tableName)).thenReturn(true);
        Schema schema = new Schema();
        schema.setSchema(existingSchema);
        schema.setTableName(tableName);
        Mockito.when(schemaRepository.findByTableName(tableName)).thenReturn(schema);
        URL removeColumnSchema = Resources.getResource("schemas/removeColumn.json");
        String newSchema = Resources.toString(removeColumnSchema, Charsets.UTF_8);

        // WHEN
        String actual = schemaCreatorService.handleSchemaCreation(newSchema);

        // THEN
        String expectedSql = "ALTER TABLE " + tableName + " DROP COLUMN gender";
        ArgumentCaptor<List> argument = ArgumentCaptor.forClass(List.class);
        Mockito.verify(dbService).executeSQLs(argument.capture());
        Assert.assertEquals(argument.getValue().get(0), expectedSql);
        String expectedResponse = "Schema successfully saved!";
        Assert.assertEquals(expectedResponse, actual);
    }

    @Test
    public void copyColumn() throws IOException {
        // GIVEN
        String tableName = "test";
        URL createTableSchema = Resources.getResource("schemas/createTable.json");
        String existingSchema = Resources.toString(createTableSchema, Charsets.UTF_8);
        Mockito.when(schemaRepository.existsByTableName(tableName)).thenReturn(true);
        Schema schema = new Schema();
        schema.setSchema(existingSchema);
        schema.setTableName(tableName);
        Mockito.when(schemaRepository.findByTableName(tableName)).thenReturn(schema);
        URL copyColumnSchema = Resources.getResource("schemas/copyColumn.json");
        String newSchema = Resources.toString(copyColumnSchema, Charsets.UTF_8);

        // WHEN
        String actual = schemaCreatorService.handleSchemaCreation(newSchema);

        // THEN
        String expectedSql = "ALTER TABLE " + tableName + " ADD COLUMN email VARCHAR";
        ArgumentCaptor<List> argument = ArgumentCaptor.forClass(List.class);
        Mockito.verify(dbService).executeSQLs(argument.capture());
        Assert.assertEquals(expectedSql, argument.getValue().get(0));
        String expectedResponse = "Schema successfully saved!";
        Assert.assertEquals(expectedResponse, actual);
    }

    @Test(expected = SchemaAlreadyExistsException.class)
    public void schemaAlreadyExists() throws IOException {
        // GIVEN
        String tableName = "test";
        URL createTableSchema = Resources.getResource("schemas/createTable.json");
        String input = Resources.toString(createTableSchema, Charsets.UTF_8);
        Mockito.when(schemaRepository.existsByTableName(tableName)).thenReturn(true);
        Schema schema = new Schema();
        schema.setSchema(input);
        schema.setTableName(tableName);
        Mockito.when(schemaRepository.findByTableName(tableName)).thenReturn(schema);

        // WHEN
        schemaCreatorService.handleSchemaCreation(input);
    }

    @Test(expected = InvalidOperationException.class)
    public void addNotNullColumn() throws IOException {
        // GIVEN
        String tableName = "test";
        URL createTableSchema = Resources.getResource("schemas/createTable.json");
        String existingSchema = Resources.toString(createTableSchema, Charsets.UTF_8);
        Mockito.when(schemaRepository.existsByTableName(tableName)).thenReturn(true);
        Schema schema = new Schema();
        schema.setSchema(existingSchema);
        schema.setTableName(tableName);
        Mockito.when(schemaRepository.findByTableName(tableName)).thenReturn(schema);
        URL invalidColumnSchema = Resources.getResource("schemas/addNotNullColumn.json");
        String newSchema = Resources.toString(invalidColumnSchema, Charsets.UTF_8);

        // WHEN
        schemaCreatorService.handleSchemaCreation(newSchema);
    }

    @Test(expected = InvalidFileFormatException.class)
    public void wrongJsonFormat() {
        // WHEN
        schemaCreatorService.handleSchemaCreation("");
    }

    @Test(expected = InvalidOperationException.class)
    public void removeForeignKeyColumn() throws IOException {
        // GIVEN
        String tableName = "test";
        URL createTableSchema = Resources.getResource("schemas/createTable.json");
        String existingSchema = Resources.toString(createTableSchema, Charsets.UTF_8);
        Mockito.when(schemaRepository.existsByTableName(tableName)).thenReturn(true);
        Schema schema = new Schema();
        schema.setSchema(existingSchema);
        schema.setTableName(tableName);
        Mockito.when(schemaRepository.findByTableName(tableName)).thenReturn(schema);
        URL invalidColumnSchema = Resources.getResource("schemas/removeForeignKeyColumn.json");
        String newSchema = Resources.toString(invalidColumnSchema, Charsets.UTF_8);

        // WHEN
        schemaCreatorService.handleSchemaCreation(newSchema);
    }

    @Test(expected = InvalidFileFormatException.class)
    public void wrongJsonSchemaFormat() throws IOException {
        // GIVEN
        URL wrongJsonSchema = Resources.getResource("schemas/wrongJsonSchema.json");
        String newSchema = Resources.toString(wrongJsonSchema, Charsets.UTF_8);

        // WHEN
        schemaCreatorService.handleSchemaCreation(newSchema);
    }

    @Test(expected = InvalidOperationException.class)
    public void alterColumn() throws IOException {
        // GIVEN
        String tableName = "test";
        URL createTableSchema = Resources.getResource("schemas/createTable.json");
        String existingSchema = Resources.toString(createTableSchema, Charsets.UTF_8);
        Mockito.when(schemaRepository.existsByTableName(tableName)).thenReturn(true);
        Schema schema = new Schema();
        schema.setSchema(existingSchema);
        schema.setTableName(tableName);
        Mockito.when(schemaRepository.findByTableName(tableName)).thenReturn(schema);
        URL alterColumnSchema = Resources.getResource("schemas/alterColumn.json");
        String newSchema = Resources.toString(alterColumnSchema, Charsets.UTF_8);

        // WHEN
        schemaCreatorService.handleSchemaCreation(newSchema);
    }
}
